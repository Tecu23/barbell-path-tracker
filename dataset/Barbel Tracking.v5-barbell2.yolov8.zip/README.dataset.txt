# Barbel Tracking > barbell2
https://universe.roboflow.com/babell-tracking/barbel-tracking-za7nr

Provided by a Roboflow user
License: CC BY 4.0

